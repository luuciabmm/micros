void espera(int tiempo);
void Bin2Ascii(unsigned short numero, unsigned char* cadena);
